//
//  PokemonView.swift
//  lab5
//
//  Created by Bilash Sarkar on 2/28/25.
//

import SwiftUI

struct Pokemon: Decodable {
    let name: String
    let url: String
}

struct PokemonList: Decodable {
    let results: [Pokemon]
}

struct PokemonView: View {
    @State private var pokemonList = [Pokemon]()
    
    var body: some View {
        NavigationView {
            List(pokemonList, id: \.name) { pokemon in
                VStack(alignment: .leading) {
                    Text(pokemon.name.capitalized)
                        .font(.headline)
                        .foregroundColor(.cyan)
                    Text(pokemon.url)
                        .font(.body)
                        .foregroundColor(.indigo)
                        .lineLimit(1) // Show only one line
                }
            }
            .navigationTitle("Pokémon List")
            .task {
                await fetchPokemonData()
            }
        }
    }
    
    func fetchPokemonData() async {
        guard let url = URL(string: "https://pokeapi.co/api/v2/pokemon?limit=50") else {
            print("Invalid Pokémon API URL!")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decodedResponse = try? JSONDecoder().decode(PokemonList.self, from: data) {
                pokemonList = decodedResponse.results // Store the list of Pokémon
            }
        } catch {
            print("Failed to fetch Pokémon data!")
        }
    }
}

struct PokemonView_Previews: PreviewProvider {
    static var previews: some View {
        PokemonView()
    }
}
