//
//  ContentView.swift
//  lab5
//
//  Created by Bilash Sarkar on 2/26/25.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView {
            
            VStack {
                // 1) JSON URL https://api.coinbase.com/v2/currencies
                NavigationLink(destination: CurrencyView()) {
                     Text("World Currency Abbreviations")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
            
                
                // 2) JSON URL  https://jsonplaceholder.typicode.com/todos
                NavigationLink(destination: TodosView()) {
                     Text("TO DO LIST")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
                // 3) JSON URL  https://restcountries.com/v3.1/all
                NavigationLink(destination: CountryView()) {
                     Text("Country List")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
                // 4) JSON URL  https://api.spacexdata.com/v4/launches
                NavigationLink(destination: SpaceXView()) {
                     Text("SpaceX List")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
                // 5) JSON URL  https://pokeapi.co/api/v2/pokemon?limit=50
                NavigationLink(destination: PokemonView()) {
                     Text("Pokemon List")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
            }  // end vertical Stack
            .navigationTitle("JSON URLs")
            
            
        } // end navigation view
        
    } // end body
    
} // end struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
    
}
