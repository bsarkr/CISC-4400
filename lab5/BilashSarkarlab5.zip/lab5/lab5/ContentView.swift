//
//  ContentView.swift
//  lab5
//
//  Created by Bilash Sarkar on 2/26/25.
//

import SwiftUI

struct ContentView: View {
    
    var body: some View {
        NavigationView {
            
            VStack {
                // 1) JSON URL  ------------
                NavigationLink(destination: CurrencyView()) {
                     Text("World Currency Abbreviations")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
            
                
                // 2) JSON URL  ------------
                NavigationLink(destination: TodosView()) {
                     Text("TO DO LIST")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
                // 3) JSON URL  ------------
                NavigationLink(destination: CountryView()) {
                     Text("Country List")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
                // 4) JSON URL  ------------
                NavigationLink(destination: SpaceXView()) {
                     Text("SpaceX List")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
                // 5) JSON URL  ------------
                NavigationLink(destination: PokemonView()) {
                     Text("Pokemon List")
                        .font(.title3)
                        .padding(.bottom, 15)
                }
                
            }  // end vertical Stack
            .navigationTitle("JSON URLs")
            
            
        } // end navigation view
        
    } // end body
    
} // end struct

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
    
}
