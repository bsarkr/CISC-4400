//
//  CountryView.swift
//  lab5
//
//  Created by Bilash Sarkar on 2/28/25.
//


import SwiftUI

struct Country: Decodable {
    let id: String
    let name: String
    let area: Double
    
    enum CodingKeys: String, CodingKey {
        case id = "cca2"
        case name
        case area
    }
    
    struct Name: Decodable {
        let common: String
    }
    
    init(from decoder: Decoder) throws {
        let container = try decoder.container(keyedBy: CodingKeys.self)
        id = try container.decode(String.self, forKey: .id)
        area = try container.decode(Double.self, forKey: .area)
        
        let nameContainer = try container.decode(Name.self, forKey: .name)
        name = nameContainer.common
    }
}

struct CountryView: View {
    @State private var countries = [Country]()
    
    var body: some View {
        NavigationView {
            List(countries, id: \.id) { c in
                VStack(alignment: .leading) {
                    Text(c.id)
                        .font(.headline)
                        .foregroundColor(.cyan)
                    Text(c.name)
                        .font(.body)
                        .foregroundColor(.indigo)
                    Text("Area: \(c.area, specifier: "%.2f") sq km")
                        .font(.body)
                        .foregroundColor(.red)
                }
            }
            .navigationTitle("Countries")
            .task {
                await fetchCountryData()
            }
        }
    }
    
    func fetchCountryData() async {
        guard let url = URL(string: "https://restcountries.com/v3.1/all") else {
            print("Hey Man, THIS URL DOES NOT WORK!")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            
            if let decodedResponse = try? JSONDecoder().decode([Country].self, from: data) {
                countries = decodedResponse
            } else {
                print("Decoding error: Data format might be incorrect")
            }
        } catch {
            print("Error fetching data: \(error.localizedDescription)")
        }
    }
}

struct CountryView_Previews: PreviewProvider {
    static var previews: some View {
        CountryView()
    }
}
