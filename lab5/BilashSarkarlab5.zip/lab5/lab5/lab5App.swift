//
//  lab5App.swift
//  lab5
//
//  Created by Bilash Sarkar on 2/26/25.
//

import SwiftUI

@main
struct lab5App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
