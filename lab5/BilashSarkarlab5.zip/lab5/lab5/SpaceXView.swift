//
//  SpaceXView.swift
//  lab5
//
//  Created by Bilash Sarkar on 2/28/25.
//

import SwiftUI

struct Launch: Decodable {
    let id: String
    let name: String
    let dateUTC: String
    let success: Bool?
    
    enum CodingKeys: String, CodingKey {
        case id
        case name
        case dateUTC = "date_utc"
        case success
    }
}

struct SpaceXView: View {
    @State private var launches = [Launch]()
    
    var body: some View {
        NavigationView {
            List(launches, id: \.id) { launch in
                VStack(alignment: .leading) {
                    Text(launch.name)
                        .font(.headline)
                        .foregroundColor(.cyan)
                    Text("Date: \(launch.dateUTC)")
                        .font(.body)
                        .foregroundColor(.indigo)
                    Text("Success: \(launch.success == true ? "Yes" : "No")")
                        .font(.body)
                        .foregroundColor(launch.success == true ? .green : .red)
                }
            }
            .navigationTitle("SpaceX Launches")
            .task {
                await fetchLaunchData()
            }
        }
    }
    
    func fetchLaunchData() async {
        guard let url = URL(string: "https://api.spacexdata.com/v4/launches") else {
            print("Invalid URL!")
            return
        }
        
        do {
            let (data, _) = try await URLSession.shared.data(from: url)
            if let decodedResponse = try? JSONDecoder().decode([Launch].self, from: data) {
                launches = decodedResponse // Store multiple launches
            }
        } catch {
            print("Failed to fetch SpaceX data!")
        }
    }
}

struct SpaceXView_Previews: PreviewProvider {
    static var previews: some View {
        SpaceXView()
    }
}
