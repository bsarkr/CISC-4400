//
//  lab5Tests.swift
//  lab5Tests
//
//  Created by Bilash Sarkar on 2/26/25.
//

import Testing
@testable import lab5

struct lab5Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
