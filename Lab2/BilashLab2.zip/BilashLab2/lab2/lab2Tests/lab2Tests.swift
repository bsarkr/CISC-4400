//
//  lab2Tests.swift
//  lab2Tests
//
//  Created by Bilash Sarkar on 2/7/25.
//

import Testing
@testable import lab2

struct lab2Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
