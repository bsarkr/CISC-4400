//
//  lab2App.swift
//  lab2
//
//  Created by Bilash Sarkar on 2/7/25.
//

import SwiftUI

@main
struct lab2App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
