import SwiftUI

struct ContentView: View {
    @State var companyName = ""
    @State var address = ""
    @State var city = ""
    @State var state = ""
    @State var zipcode = ""
    @State var phoneNum = ""
    @State var email = ""
    @State var mobilePhone = ""
    @State var mobileCarrier = ""
    @State var username = ""
    @State var password = ""
    @State var reTypePassword = ""
    @State var allValid: Bool = false
    @State var formSubmitted: Bool = false
    @State var errorMsg = ""

    let validStates: Set<String> = [
        "AL", "AK", "AZ", "AR", "CA", "CO", "CT", "DE", "FL", "GA",
        "HI", "ID", "IL", "IN", "IA", "KS", "KY", "LA", "ME", "MD",
        "MA", "MI", "MN", "MS", "MO", "MT", "NE", "NV", "NH", "NJ",
        "NM", "NY", "NC", "ND", "OH", "OK", "OR", "PA", "RI", "SC",
        "SD", "TN", "TX", "UT", "VT", "VA", "WA", "WV", "WI", "WY"
    ]

    let validCarriers: Set<String> = ["Verizon", "AT&T", "T-Mobile"]

    var body: some View {
        VStack {
            if !formSubmitted {
                Form {
                    TextField("Company Name", text: $companyName)
                    TextField("Address", text: $address)
                    TextField("City", text: $city)
                    TextField("State", text: $state)
                    TextField("Zipcode", text: $zipcode)
                    TextField("Phone Number", text: $phoneNum)
                    TextField("Email Address", text: $email)
                    TextField("Mobile Phone", text: $mobilePhone)
                    TextField("Mobile Carrier", text: $mobileCarrier)
                    TextField("Username", text: $username)
                    SecureField("Password", text: $password)
                    SecureField("Re-Type Password", text: $reTypePassword)
                }
                .frame(maxHeight: 580)
                .padding(.bottom, 10)

                Spacer() 

                Button(action: {
                    validateForm()
                }) {
                    Text("Submit")
                        .frame(maxWidth: .infinity)
                        .padding()
                        .background(Color.blue)
                        .foregroundColor(.white)
                        .cornerRadius(8)
                }
                .padding(.horizontal)

                if !allValid {
                    Text(errorMsg)
                        .padding()
                        .foregroundColor(.red)
                        .multilineTextAlignment(.center)
                }
            } else {
                ZStack {
                    Rectangle()
                        .fill(Color.purple.opacity(0.3))
                        .frame(width: 300, height: 150)
                        .cornerRadius(10)
                        .shadow(radius: 5)

                    Text("New Customer was Added")
                        .font(.title2)
                        .fontWeight(.bold)
                        .foregroundColor(.black)
                }
            }
        }
        .padding()
        .ignoresSafeArea(.keyboard, edges: .bottom) 
    }

    func validateForm() {
        if companyName.count < 5 {
            errorMsg = "Company name must be greater than 5 characters :)"
            allValid = false
            return
        } else if address.count < 5 {
            errorMsg = "Address must be greater than 5 characters :)"
            allValid = false
            return
        } else if city.count < 5 {
            errorMsg = "City name must be greater than 5 characters :)"
            allValid = false
            return
        } else if !validStates.contains(state) {
            errorMsg = "State abbreviation must be accurate"
            allValid = false
            return
        } else if !validZipcode(zipcode) {
            errorMsg = "Please enter a 5-digit zipcode"
            allValid = false
            return
        } else if !validPhone(phoneNum) {
            errorMsg = "Please enter a 10-digit phone number"
            allValid = false
            return
        } else if !email.contains("@") || !email.contains(".") || email.count < 5 {
            errorMsg = "Please enter a valid email address: example@example.example"
            allValid = false
            return
        } else if !validPhone(mobilePhone) {
            errorMsg = "Please enter a 10-digit phone number"
            allValid = false
            return
        } else if !validCarriers.contains(mobileCarrier) {
            errorMsg = "Please enter a valid carrier: (AT&T, T-Mobile, or Verizon)"
            allValid = false
            return
        } else if !validUser(username) {
            errorMsg = "Please enter a valid username: min 10 characters and no spaces"
            allValid = false
            return
        } else if !validPass(password) {
            errorMsg = "Password must be at least 10 characters and include an uppercase letter"
            allValid = false
            return
        } else if password != reTypePassword {
            errorMsg = "Passwords do not match"
            allValid = false
            return
        }

        allValid = true
        formSubmitted = true
    }

    func validZipcode(_ code: String) -> Bool {
        return code.allSatisfy { $0.isNumber } && code.count == 5
    }

    func validPhone(_ code: String) -> Bool {
        return code.allSatisfy { $0.isNumber } && code.count == 10
    }

    func validUser(_ code: String) -> Bool {
        return !code.contains(" ") && code.count >= 10
    }

    func validPass(_ code: String) -> Bool {
        let hasUppercase = code.range(of: "[A-Z]", options: .regularExpression) != nil
        return hasUppercase && code.count >= 10
    }
}

#Preview {
    ContentView()
}
