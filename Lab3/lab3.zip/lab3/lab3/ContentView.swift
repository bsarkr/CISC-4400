//
//  ContentView.swift
//  lab3
//
//  Created by Bilash Sarkar on 2/14/25.
//

import SwiftUI

struct ContentView: View {
    
    @State private var card1:String = "card1"
    @State private var card2:String = "card2"
    @State private var card3:String = "card3"
    @State private var card4:String = "card4"
    @State private var card5:String = "card5"
    @State private var card6:String = "card6"
    @State private var card7:String = "card7"
    @State private var card8:String = "card8"
    @State private var card9:String = "card9"
    @State private var card10:String = "card10"
    @State private var resultMessage:String = ""
    
    var body: some View {
        VStack {
            HStack {
                Image(card1)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card2)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card3)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card4)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card5)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
            } // end HStack
            
            HStack {
                Image(card6)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card7)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card8)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card9)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
                Image(card10)
                    .resizable()
                    .aspectRatio(contentMode: .fit)
                
            } // end HStack
            
            Button(action: {
                //
                // Swift Code-generate random number between 1 and 13
                //
                
                var numbers: [Int] = [] //creating an empty array to store card info
                
                var randomNumber:Int = 0
                
                for i in 1...10 {
                    
                    if i == 1 {
                        randomNumber = Int.random(in: 1...67)
                        card1 = String(randomNumber)
                    }
                    else if i == 2 {
                        randomNumber = Int.random(in: 1...67)
                        card2 = String(randomNumber)
                    }
                    else if i == 3 {
                        randomNumber = Int.random(in: 1...67)
                        card3 = String(randomNumber)
                    }
                    else if i == 4 {
                        randomNumber = Int.random(in: 1...67)
                        card4 = String(randomNumber)
                    }
                    else if i == 5 {
                        randomNumber = Int.random(in: 1...67)
                        card5 = String(randomNumber)
                    }
                    else if i == 6 {
                        randomNumber = Int.random(in: 1...67)
                        card6 = String(randomNumber)
                    }
                    else if i == 7 {
                        randomNumber = Int.random(in: 1...67)
                        card7 = String(randomNumber)
                    }
                    else if i == 8 {
                        randomNumber = Int.random(in: 1...67)
                        card8 = String(randomNumber)
                    }
                    else if i == 9 {
                        randomNumber = Int.random(in: 1...67)
                        card9 = String(randomNumber)
                    }
                    else if i == 10 {
                        randomNumber = Int.random(in: 1...67)
                        card10 = String(randomNumber)
                    }
                    
                    numbers.append(randomNumber) //adding number to array
                    
                    resultMessage = "High : \(numbers.max()!)" + "\n" +
                                    "Low  : \(numbers.min()!)" + "\n" +
                                    "Freq : \(numbers.count)"
                    
                } // end for loopa
            }, label: {
                Text("RANDOM")
                    .padding()
                    .foregroundColor(Color.green)
                    .font(.largeTitle)
                
            }) // end button
            
            Text(resultMessage)
                .frame(width: 275, height: 70, alignment: .leading)
                .background(Color.green)
                .foregroundColor(Color.black)
            
            
        } // end VStack
        
    } // end body
    
} // end struct


struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

