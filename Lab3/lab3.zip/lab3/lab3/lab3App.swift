//
//  lab3App.swift
//  lab3
//
//  Created by Bilash Sarkar on 2/14/25.
//

import SwiftUI

@main
struct lab3App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
