//
//  lab3Tests.swift
//  lab3Tests
//
//  Created by Bilash Sarkar on 2/14/25.
//

import Testing
@testable import lab3

struct lab3Tests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
